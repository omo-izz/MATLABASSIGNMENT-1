




img1_raw = imread('C:\Users\HP\Pictures\banana_leaf.jpg'); 
img1_gray = rgb2gray(img1_raw);
img1_enhanced = histeq(img1_gray); 


img2_raw = imread('C:\Users\HP\Pictures\cassava_leaf.jpg');
img2_gray = rgb2gray(img2_raw);
img2_filtered = medfilt2(img2_gray); 


img3_raw = imread('C:\Users\HP\Pictures\groundnut_leaf.jpg');
img3_gray = rgb2gray(img3_raw);
img3_binary = imbinarize(img3_gray); 

img4_raw = imread('C:\Users\HP\Pictures\bean_leaf.jpg');
img4_gray = rgb2gray(img4_raw);
img4_edges = edge(img4_gray, 'Sobel'); 


img5_raw = imread('C:\Users\HP\Pictures\maize_leaf.jpg');
img5_gray = rgb2gray(img5_raw);
img5_adjusted = imadjust(img5_gray); 





leaves(1).Name = 'Banana';
leaves(1).Type = 'Simple';
leaves(1).Venation = 'Parallel (Pinnately Parallel)';
leaves(1).Arrangement = 'Spiral';
leaves(1).Margin = 'Entire';
leaves(1).Class = 'Monocotyledonous';
leaves(1).OriginalImage = img1_raw;
leaves(1).ProcessedImage = img1_enhanced;
leaves(1).ProcessingMethod = 'Histogram Equalization';

leaves(2).Name = 'Cassava';
leaves(2).Type = 'Compound (Palmate / Deeply Lobed)';
leaves(2).Venation = 'Reticulate (Palmate)';
leaves(2).Arrangement = 'Alternate';
leaves(2).Margin = 'Lobed';
leaves(2).Class = 'Dicotyledonous';
leaves(2).OriginalImage = img2_raw;
leaves(2).ProcessedImage = img2_filtered;
leaves(2).ProcessingMethod = 'Median Filtering';


leaves(3).Name = 'Groundnut';
leaves(3).Type = 'Compound (Paripinnate / 4 Leaflets)';
leaves(3).Venation = 'Reticulate';
leaves(3).Arrangement = 'Alternate';
leaves(3).Margin = 'Entire';
leaves(3).Class = 'Dicotyledonous';
leaves(3).OriginalImage = img3_raw;
leaves(3).ProcessedImage = img3_binary;
leaves(3).ProcessingMethod = 'Binary Thresholding';


leaves(4).Name = 'Bean';
leaves(4).Type = 'Compound (Trifoliate / 3 Leaflets)';
leaves(4).Venation = 'Reticulate';
leaves(4).Arrangement = 'Alternate';
leaves(4).Margin = 'Entire';
leaves(4).Class = 'Dicotyledonous';
leaves(4).OriginalImage = img4_raw;
leaves(4).ProcessedImage = img4_edges;
leaves(4).ProcessingMethod = 'Sobel Edge Detection';


leaves(5).Name = 'Maize';
leaves(5).Type = 'Simple';
leaves(5).Venation = 'Parallel';
leaves(5).Arrangement = 'Alternate';
leaves(5).Margin = 'Entire';
leaves(5).Class = 'Monocotyledonous';
leaves(5).OriginalImage = img5_raw;
leaves(5).ProcessedImage = img5_adjusted;
leaves(5).ProcessingMethod = 'Contrast Adjustment';




for i = 1:length(leaves)
    
    figure('Name', sprintf('Leaf Analysis: %s', leaves(i).Name));
    
    subplot(1, 2, 1);
    imshow(leaves(i).OriginalImage);
    title(sprintf('%s (Original)', leaves(i).Name));
    
    subplot(1, 2, 2);
    imshow(leaves(i).ProcessedImage);
    title(sprintf('Processed: %s', leaves(i).ProcessingMethod));
    
    
    fprintf('=== LEAF %d: %s ===\n', i, upper(leaves(i).Name));
    fprintf('Class:            %s\n', leaves(i).Class);
    fprintf('Leaf Type:        %s\n', leaves(i).Type);
    fprintf('Venation:         %s\n', leaves(i).Venation);
    fprintf('Arrangement:      %s\n', leaves(i).Arrangement);
    fprintf('Margin:           %s\n', leaves(i).Margin);
    fprintf('Image Processed:  %s\n\n', leaves(i).ProcessingMethod);
end
for i = 1:length(leaves)
    % (Your figure creation and subplot code goes here...)
    fig = figure('Name', sprintf('Leaf Analysis: %s', leaves(i).Name));
    
   
    
    % Save the full side-by-side figure window as PNG
    figureFileName = fullfile(outputDir, sprintf('%s_comparison.png', lower(leaves(i).Name)));
    saveas(fig, figureFileName);
end